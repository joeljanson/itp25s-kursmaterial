const app = Vue.createApp({
	components: { NavBar },
});
app.mount("#app");
