const NavBar = {
	template: `
    <nav>
		<div class="logo">Joel Janson Johansen</div>
		<ul class="nav-links">
			<li><a href="index.html">Hem</a></li>
			<li><a href="about.html">Om</a></li>
			<li><a href="contact.html">Kontakt</a></li>
		</ul>
	</nav>
  `,
};
